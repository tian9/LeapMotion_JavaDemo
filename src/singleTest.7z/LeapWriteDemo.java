import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URISyntaxException;





public class LeapWriteDemo {

	/**
	 * @param args
	 */
	static int num = 0;
	public static File seqFile,tableFile;
	public static File accountFile = null; 



	public static void main(String[] args) {

		// initialize the log in window
		LeapWriteWin loginWin = new LeapWriteWin( );
		loginWin.frameDesign();
		//loginWin.setVisible(true);


		File jarFile = null;
		try {
			jarFile = (new File(LeapWriteDemo.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath()));
		} catch (URISyntaxException e) {

			e.printStackTrace();
		}
		LeapWriteWin.savePath = jarFile.getParentFile().getPath() + "\\Signatures\\";


		seqFile =new File(LeapWriteWin.savePath + "0_sequencialNum");
		accountFile = new File(LeapWriteWin.savePath + "0_Account");
		tableFile = new File(LeapWriteWin.savePath + "0_TableDTW");

		calSeqNum();
		writeSeqNum(seqFile,num);
		System.out.println(TableDTW.totalSeqNum);


		if (accountFile.exists()){
			UserDataAll.readAccount();
			System.out.println("Read ACCOUNT INFO from the existing file");

		} else{
			UserDataAll.createAccount();
			UserDataAll.saveAccount(accountFile);	
			System.out.println("Saved the account info");


		}
		
		
		if (tableFile.exists()){
			TableDTW.readTable();
			System.out.println("Read DTW Table from the existing file");

		} else{
			System.out.println("Try to create a  DTW Table");
			TableDTW.createTable(TableDTW.totalSeqNum);
			System.out.println("Created DTW Table");
			TableDTW.saveTable(tableFile, TableDTW.tableDTW, TableDTW.totalSeqNum);
			System.out.println("Saved DTW Table");


		}
		
		loginWin.setVisible(true);
		// System.out.println("The path of the jar is" + LeapWriteWin.savePath);

	}



	// read the sequencial number
	private static int readSeqNum(){

		try {		
			FileReader fileReader = new FileReader(seqFile);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			num = bufferedReader.read();
			bufferedReader.close();
			fileReader.close();

		} catch (IOException e) {
			// 
			e.printStackTrace();
		}

		return num;
	}

	private static int calSeqNum(){
		File dir = new File(LeapWriteWin.savePath);
		File[] dirListing = dir.listFiles();
		if(dirListing != null){
			for (File allFile: dirListing){
				String currentFileName = allFile.getName();				
				if (currentFileName.endsWith("NormedFeature.txt") && !currentFileName.startsWith("FAILED")){
					num ++;
				}
			}
			TableDTW.totalSeqNum = num;

		}
		return num;

	} // end method

	private static void writeSeqNum(File file,int num){
		Writer writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(file));
			String content = Integer.toString(num); 
			writer.write(content);
		} catch (IOException ex) {
			// report
		} finally {
			try {writer.close();} catch (Exception ex) {}
		}
	}

}// end class
