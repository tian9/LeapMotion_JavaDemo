
import jnisvmlight.LabeledFeatureVector;
import jnisvmlight.SVMLightModel;
import jnisvmlight.SVMLightInterface;
import jnisvmlight.TrainingParameters;

public class LeapSVM {

  public static int N = TableDTW.totalSeqNum -1; // number of training docs
  public static int M = 1; // max. number of features per doc

  public  String currUserName;
  public  boolean verified = false;
  
  public LeapSVM(String currUserName){
	this.currUserName = currUserName;  
  }
  
  public boolean getResults(){
	  return this.verified;
  }
  
  public  void trainTest() throws Exception {
	  
    

    // The trainer interface with the native communication to the SVM-light 
    // shared libraries
    SVMLightInterface trainer = new SVMLightInterface();

    // The training data
    LabeledFeatureVector[] traindata = new LabeledFeatureVector[N];
    LabeledFeatureVector[] testdata = new LabeledFeatureVector[M];


    // Sort all feature vectors in ascedending order of feature dimensions
    // before training the model
    SVMLightInterface.SORT_INPUT_VECTORS = true;

    
    for (int i = 0; i < TableDTW.totalSeqNum; i++) {
    	//each sample (a row)
      int[] dims = new int[TableDTW.totalSeqNum - 1];
      double[] values = new double[TableDTW.totalSeqNum - 1];
    
    
          // Fill the vectors
    for (int j = 0; j < TableDTW.totalSeqNum; j++) {
    	dims[j] = j+1;
    	values[j] = TableDTW.tableDTW[i][j];
    }
    
     // Store dimension/value pairs in new LabeledFeatureVector object
      UserDataSeq ud = new UserDataSeq(i);
      String userName = ud.userData.userName;
     if(i != TableDTW.totalSeqNum - 1){
      if (userName.equals(currUserName)){
    	  traindata[i] = new LabeledFeatureVector(+1, dims, values);
      } else{
      traindata[i] = new LabeledFeatureVector(-1, dims, values);
      traindata[i].normalizeL2();
      System.out.println(traindata[i].toString());
      }
     }else{
    	 testdata[1] = new LabeledFeatureVector(+1, dims, values);
     }
      
      System.out.println(" DONE.");
    }


    
    // Initialize a new TrainingParamteres object with the default SVM-light
    // values
    TrainingParameters tp = new TrainingParameters();

    // Switch on some debugging output
    tp.getLearningParameters().verbosity = 1;

    System.out.println("\nTRAINING SVM-light MODEL ..");
    SVMLightModel model = trainer.trainModel(traindata, tp);
    System.out.println(" DONE.");

    // Use this to store a model to a file or read a model from a URL.
    model.writeModelToFile("jni_model.dat");
    model = SVMLightModel.readSVMLightModelFromURL(new java.io.File("jni_model.dat").toURL());
    
    // Use the classifier on the randomly created feature vectors
    System.out.println("\nVALIDATING SVM-light MODEL in Java..");
    
    
     double d = model.classify(testdata[1]);
      
      if (d < 0){
    	  verified = false;
      } else
    	  verified = true;
          
  }
}
